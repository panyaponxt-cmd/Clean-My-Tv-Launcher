# CleanMyTV Android TV Launcher

A dark, remote-friendly Android HOME/Leanback launcher starter project.

## Included
- Dark dashboard with storage summary.
- List of launchable installed apps; select one to open it or view Android App Info.
- HOME / DEFAULT / LEANBACK_LAUNCHER intent filters. Android still asks the user to choose the default Home app.
- D-pad focusable controls.
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Compatibility notes
- Minimum SDK: 14 (Android 4.0). Android 4.x is not necessarily Android TV; TV-specific behavior depends on the device firmware.
- Target SDK: 28. The project uses JDK 17 / Gradle 8.9 / Android Gradle Plugin 8.7.3.
- The app cannot silently become the default launcher, uninstall apps, clear other apps' data, or remove protected system apps. Android controls those actions.
- The Holo theme is used because Material theme requires newer Android versions than the API 14 minimum.
- Compatibility with a specific television must be tested on that device.

## Build from a phone with GitHub
1. Extract this ZIP.
2. Upload the extracted **contents** to the root of your GitHub repository (not the ZIP itself). Keep the `.github/workflows/build-apk.yml` file and its folders.
3. Open the repository's **Actions** tab.
4. Select **Build CleanMyTV APK** and tap **Run workflow** (or push to `main`).
5. When the run is green, open it and download the `CleanMyTV-debug-apk` artifact.
6. Extract the downloaded artifact ZIP. The APK is `app-debug.apk`.

This ZIP contains Android source code and the automated build workflow; it is not itself an APK. A successful APK build has not been verified in this environment. The output is a debug APK for testing, not a Play Store release.
