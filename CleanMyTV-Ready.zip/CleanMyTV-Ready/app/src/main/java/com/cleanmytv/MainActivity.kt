package com.cleanmytv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 21, 29)
    private val panel = Color.rgb(27, 36, 48)
    private val mint = Color.rgb(101, 230, 196)
    private val white = Color.WHITE
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        render()
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(42, 28, 42, 24); setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(text("CleanMyTV", 34, mint, true))
        content.addView(text("จัดการ Android TV ของคุณในที่เดียว", 17, Color.LTGRAY, false))
        content.addView(space(20))
        val stats = storageSummary()
        content.addView(card("พื้นที่จัดเก็บ", stats))
        content.addView(space(14))
        val launcher = button("ตั้งเป็น Launcher หลัก") { openHomeSettings() }
        content.addView(launcher)
        content.addView(space(10))
        content.addView(button("เปิดการตั้งค่า Android TV") { startActivity(Intent(Settings.ACTION_SETTINGS)) })
        content.addView(space(24))
        content.addView(text("แอปที่ติดตั้ง", 24, white, true))
        content.addView(text("เลือกแอปเพื่อเปิดรายละเอียดหรือถอนการติดตั้ง", 14, Color.LTGRAY, false))
        content.addView(space(10))
        val apps = packageManager.getInstalledApplications(0)
            .filter { it.packageName != packageName && packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }
        if (apps.isEmpty()) content.addView(text("ไม่พบแอปที่แสดงได้", 16, white, false))
        apps.forEach { info ->
            val name = packageManager.getApplicationLabel(info).toString()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 10, 16, 10); setBackgroundColor(panel); isFocusable = true; isFocusableInTouchMode = true }
            val label = TextView(this).apply { text = name; textSize = 18f; setTextColor(white) }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            val open = TextView(this).apply { text = "รายละเอียด  ›"; textSize = 15f; setTextColor(mint); setPadding(14, 12, 14, 12); isFocusable = true; setOnClickListener { showAppActions(info) } }
            row.addView(open)
            row.setOnClickListener { showAppActions(info) }
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
        }
        content.addView(space(18))
        content.addView(text("CleanMyTV 1.0 • การดำเนินการถอนติดตั้งต้องได้รับการยืนยันจาก Android", 12, Color.GRAY, false))
        setContentView(root)
        root.isFocusableInTouchMode = true
        root.requestFocus()
    }

    private fun storageSummary(): String {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val total: Long
            val free: Long
            if (android.os.Build.VERSION.SDK_INT >= 18) {
                total = stat.totalBytes
                free = stat.availableBytes
            } else {
                @Suppress("DEPRECATION")
                val blockSize = stat.blockSize.toLong()
                @Suppress("DEPRECATION")
                total = stat.blockCount.toLong() * blockSize
                @Suppress("DEPRECATION")
                free = stat.availableBlocks.toLong() * blockSize
            }
            "ใช้ไป ${formatBytes(total - free)} จาก ${formatBytes(total)}  •  ว่าง ${formatBytes(free)}"
        } catch (_: Exception) { "ไม่สามารถอ่านข้อมูลพื้นที่จัดเก็บได้บนอุปกรณ์นี้" }
    }

    private fun formatBytes(value: Long): String {
        val gb = value / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1) String.format(Locale.getDefault(), "%.1f GB", gb) else String.format(Locale.getDefault(), "%.0f MB", value / (1024.0 * 1024.0))
    }

    private fun showAppActions(info: ApplicationInfo) {
        val name = packageManager.getApplicationLabel(info).toString()
        val options = arrayOf("เปิดแอป", "ข้อมูลแอป / ถอนการติดตั้ง", "ยกเลิก")
        AlertDialog.Builder(this).setTitle(name).setItems(options) { _, which ->
            when (which) {
                0 -> packageManager.getLaunchIntentForPackage(info.packageName)?.let { startActivity(it) }
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = android.net.Uri.parse("package:${info.packageName}") })
            }
        }.show()
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent("android.settings.HOME_SETTINGS"))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 5, 0, 5)
    }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, height) }
    private fun card(title: String, body: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(20, 16, 20, 16); setBackgroundColor(panel)
        addView(text(title, 17, mint, true)); addView(text(body, 19, white, false))
    }
    private fun button(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 19f; setTextColor(bg); setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        setPadding(18, 17, 18, 17); setBackgroundColor(mint); isFocusable = true; isFocusableInTouchMode = true; setOnClickListener { action() }
    }
}
