package com.cleanmytv

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 11, 22)
    private val panel = Color.rgb(17, 25, 43)
    private val blue = Color.rgb(75, 151, 255)
    private val white = Color.rgb(244, 247, 255)
    private val muted = Color.rgb(157, 171, 196)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildScreen()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(2), stroke)
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = false
        }
    }

    private fun buildScreen() {
        val scroller = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(bg)
            clipToPadding = false
            setPadding(dp(42), dp(22), dp(42), dp(42))
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        scroller.addView(root)
        setContentView(scroller)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = text("CLEAN  MY  TV", 19f, white, true)
        brand.letterSpacing = 0.12f
        top.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        listOf("Home", "Movies", "Series", "Apps", "Settings").forEachIndexed { index, label ->
            val item = text(label, 14f, if (index == 0) white else muted, index == 0).apply {
                gravity = Gravity.CENTER
                setPadding(dp(13), 0, dp(13), 0)
                if (index == 0) background = rounded(Color.rgb(28, 47, 76), 18, blue)
                isFocusable = true
                setOnClickListener { Toast.makeText(this@MainActivity, "$label section", Toast.LENGTH_SHORT).show() }
            }
            top.addView(item, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply {
                marginStart = dp(5)
            })
            attachFocus(item)
        }
        root.addView(top)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(34), dp(26), dp(34), dp(26))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(29, 59, 100), Color.rgb(18, 35, 63), Color.rgb(15, 23, 40))
            ).apply { cornerRadius = dp(24).toFloat() }
        }
        val heroParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
        heroParams.topMargin = dp(22)
        root.addView(hero, heroParams)
        hero.addView(text("FEATURED  •  CLEANMYTV ORIGINALS", 11f, Color.rgb(160, 202, 255), true))
        hero.addView(text("Your screen.\\nYour cinema.", 32f, white, true).apply {
            setLineSpacing(dp(1).toFloat(), 1f)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(88)))
        hero.addView(text("A calmer way to explore what you love.", 14f, Color.rgb(206, 218, 238)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val explore = actionPill("Explore movies", true) {
            Toast.makeText(this@MainActivity, "Movie library demo", Toast.LENGTH_SHORT).show()
        }
        val settings = actionPill("Customize", false) {
            Toast.makeText(this@MainActivity, "Settings coming soon", Toast.LENGTH_SHORT).show()
        }
        actions.addView(explore)
        actions.addView(settings, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)).apply {
            marginStart = dp(10)
        })
        hero.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)).apply {
            topMargin = dp(12)
        })

        addRail("Continue exploring", listOf("THE DEEP BLUE", "NIGHT SHIFT", "ORBITAL", "WILD EARTH", "AFTERLIGHT"))
        addRail("Popular collections", listOf("SCI-FI WORLDS", "TRUE STORIES", "ANIMATION", "MYSTERY", "ADVENTURE"))
        addRail("Your apps", listOf("YouTube", "Media Player", "Settings", "Browser", "More apps"))
        root.addView(text("CLEANMYTV 2.0     •     Designed for the big screen", 11f, muted).apply {
            setPadding(dp(2), dp(22), 0, dp(8))
        })
    }

    private fun actionPill(label: String, primary: Boolean, click: () -> Unit): TextView {
        return text(label, 13f, if (primary) Color.WHITE else white, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(if (primary) blue else Color.rgb(37, 51, 73), 22)
            isFocusable = true
            setOnClickListener { click() }
            attachFocus(this)
        }
    }

    private fun addRail(title: String, labels: List<String>) {
        root.addView(text(title, 19f, white, true).apply {
            setPadding(dp(2), dp(24), 0, dp(11))
        })
        val horizontal = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { index, label ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM
                setPadding(dp(13), dp(12), dp(13), dp(13))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    palette(index)
                ).apply { cornerRadius = dp(15).toFloat() }
                isFocusable = true
                isClickable = true
                setOnClickListener {
                    Toast.makeText(this@MainActivity, "$label • preview card", Toast.LENGTH_SHORT).show()
                }
            }
            card.addView(text(String.format("%02d", index + 1), 11f, Color.WHITE, true))
            card.addView(text(label, 12f, Color.WHITE, true), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(43)
            ))
            row.addView(card, LinearLayout.LayoutParams(dp(164), dp(112)).apply {
                marginEnd = dp(12)
            })
            attachFocus(card)
        }
        horizontal.addView(row)
        root.addView(horizontal)
    }

    private fun palette(i: Int): IntArray {
        val sets = arrayOf(
            intArrayOf(0xFF28547A.toInt(), 0xFF14263F.toInt()),
            intArrayOf(0xFF69445D.toInt(), 0xFF29233F.toInt()),
            intArrayOf(0xFF315F69.toInt(), 0xFF172B40.toInt()),
            intArrayOf(0xFF685638.toInt(), 0xFF2B2B3D.toInt()),
            intArrayOf(0xFF4D4D7D.toInt(), 0xFF202840.toInt())
        )
        return sets[i % sets.size]
    }

    private fun attachFocus(view: View) {
        view.setOnFocusChangeListener { v, focused ->
            v.animate().scaleX(if (focused) 1.055f else 1f)
                .scaleY(if (focused) 1.055f else 1f)
                .setDuration(140).start()
            if (focused) v.elevation = dp(8).toFloat() else v.elevation = 0f
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK -> {
                Toast.makeText(this, "Press Home to leave CleanMyTV", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }
}
