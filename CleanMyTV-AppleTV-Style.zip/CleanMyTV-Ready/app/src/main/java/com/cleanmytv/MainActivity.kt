package com.cleanmytv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 16)
    private val panel = Color.rgb(22, 26, 37)
    private val panel2 = Color.rgb(31, 37, 51)
    private val accent = Color.rgb(112, 190, 255)
    private val white = Color.rgb(247, 249, 255)
    private val muted = Color.rgb(164, 174, 193)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(34, 22, 34, 20)
            background = gradient(intArrayOf(Color.rgb(17, 23, 39), bg), 0, 0)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("CLEANMYTV", 13, accent, true))
        brand.addView(text("Your TV. Your space.", 27, white, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(text("HOME  •  TV", 12, muted, true))
        content.addView(header)
        content.addView(space(20))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 24, 26, 24)
            background = gradient(intArrayOf(Color.rgb(43, 68, 104), Color.rgb(24, 34, 57), Color.rgb(20, 24, 37)), 24, 1)
        }
        hero.addView(text("WELCOME BACK", 12, Color.rgb(183, 216, 255), true))
        hero.addView(space(8))
        hero.addView(text("Make your TV feel\nbrand new.", 31, white, true))
        hero.addView(space(8))
        hero.addView(text("จัดการแอปและพื้นที่จัดเก็บได้ง่าย ๆ ในหน้าจอเดียว", 15, Color.rgb(220, 228, 241), false))
        hero.addView(space(18))
        val setHome = button("ตั้งเป็น Launcher หลัก  ›", true) { openHomeSettings() }
        hero.addView(setHome, LinearLayout.LayoutParams(-1, -2))
        content.addView(hero)
        content.addView(space(18))

        content.addView(sectionTitle("ภาพรวมอุปกรณ์", "DEVICE OVERVIEW"))
        content.addView(space(10))
        val stats = storageSummary()
        val storage = card("STORAGE", "พื้นที่จัดเก็บ", stats, "◈")
        content.addView(storage)
        content.addView(space(18))

        content.addView(sectionTitle("ทางลัด", "QUICK ACCESS"))
        content.addView(space(10))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val settings = button("⚙  การตั้งค่า", false) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        val refresh = button("↻  รีเฟรช", false) { render() }
        quick.addView(settings, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 })
        quick.addView(refresh, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 8 })
        content.addView(quick)
        content.addView(space(22))

        content.addView(sectionTitle("แอปของคุณ", "YOUR APPS"))
        content.addView(text("เลือกแอปเพื่อเปิด หรือจัดการข้อมูลแอป", 14, muted, false))
        content.addView(space(10))

        val apps = packageManager.getInstalledApplications(0)
            .filter { it.packageName != packageName && packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }

        if (apps.isEmpty()) {
            content.addView(text("ยังไม่พบแอปที่เปิดจาก Launcher ได้", 16, white, false))
        }
        apps.forEach { info ->
            val name = packageManager.getApplicationLabel(info).toString()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16, 11, 14, 11)
                background = focusBackground(panel2, accent, 16)
                isFocusable = true
                isFocusableInTouchMode = true
                setOnClickListener { showAppActions(info) }
            }
            val icon = try { packageManager.getApplicationIcon(info) } catch (_: Exception) { null }
            if (icon != null) {
                val image = ImageView(this).apply { setImageDrawable(icon); scaleType = ImageView.ScaleType.FIT_CENTER }
                row.addView(image, LinearLayout.LayoutParams(42, 42).apply { rightMargin = 14 })
            }
            val label = TextView(this).apply {
                text = name; textSize = 17f; setTextColor(white); setTypeface(null, Typeface.BOLD)
            }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("เปิด / จัดการ  ›", 13, accent, true))
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }

        content.addView(space(16))
        content.addView(text("CLEANMYTV  1.1   •   Designed for Android TV", 11, Color.rgb(105, 116, 138), true))
        setContentView(root)
        root.isFocusableInTouchMode = true
        root.requestFocus()
    }

    private fun sectionTitle(title: String, overline: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(text(overline, 10, accent, true))
        box.addView(text(title, 21, white, true))
        return box
    }

    private fun storageSummary(): String {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total: Long
            val free: Long
            if (android.os.Build.VERSION.SDK_INT >= 18) {
                total = stat.totalBytes
                free = stat.availableBytes
            } else {
                @Suppress("DEPRECATION") val blockSize = stat.blockSize.toLong()
                @Suppress("DEPRECATION") total = stat.blockCount.toLong() * blockSize
                @Suppress("DEPRECATION") free = stat.availableBlocks.toLong() * blockSize
            }
            "ใช้ไป ${formatBytes(total - free)} จาก ${formatBytes(total)}  •  ว่าง ${formatBytes(free)}"
        } catch (_: Exception) { "ไม่สามารถอ่านข้อมูลพื้นที่จัดเก็บได้บนอุปกรณ์นี้" }
    }

    private fun formatBytes(value: Long): String {
        val gb = value / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1) String.format(Locale.getDefault(), "%.1f GB", gb)
        else String.format(Locale.getDefault(), "%.0f MB", value / (1024.0 * 1024.0))
    }

    private fun showAppActions(info: ApplicationInfo) {
        val name = packageManager.getApplicationLabel(info).toString()
        val options = arrayOf("เปิดแอป", "ข้อมูลแอป / ถอนการติดตั้ง", "ยกเลิก")
        AlertDialog.Builder(this).setTitle(name).setItems(options) { _, which ->
            when (which) {
                0 -> packageManager.getLaunchIntentForPackage(info.packageName)?.let { startActivity(it) }
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:${info.packageName}")
                })
            }
        }.show()
    }

    private fun openHomeSettings() {
        try { startActivity(Intent("android.settings.HOME_SETTINGS")) }
        catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 3, 0, 3)
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    private fun card(kicker: String, title: String, body: String, symbol: String): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 17, 20, 17)
            background = rounded(panel, 18)
            addView(text(symbol, 30, accent, true), LinearLayout.LayoutParams(48, -2))
            val details = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            details.addView(text(kicker, 10, accent, true))
            details.addView(text(title, 18, white, true))
            details.addView(text(body, 14, muted, false))
            addView(details)
        }

    private fun button(label: String, primary: Boolean, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 16f
            setTextColor(if (primary) Color.rgb(8, 18, 32) else white)
            setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            setPadding(16, 16, 16, 16)
            background = focusBackground(
                if (primary) accent else panel2,
                if (primary) Color.WHITE else accent,
                16
            )
            isFocusable = true; isFocusableInTouchMode = true
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun gradient(colors: IntArray, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
            cornerRadius = radius.toFloat()
            if (stroke > 0) setStroke(1, Color.argb(75, 160, 198, 255))
        }

    private fun focusBackground(normal: Int, focused: Int, radius: Int) =
        android.graphics.drawable.StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), rounded(focused, radius))
            addState(intArrayOf(android.R.attr.state_pressed), rounded(focused, radius))
            addState(intArrayOf(), rounded(normal, radius))
        }
}
