# CleanMyTV Android TV Launcher (source project)

Dark, remote-friendly Android HOME/Leanback launcher starter.

## Compatibility target
- Minimum SDK: 14 (Android 4.0 Ice Cream Sandwich)
- Target SDK: 28
- Android 4.x is legacy Android, not the Android TV platform; Leanback and TV-specific behavior depends on vendor firmware.

## Included
- HOME + DEFAULT + LEANBACK_LAUNCHER intent filters; user chooses it in Android Home-app settings.
- Dark dashboard, device storage summary, installed launchable app list.
- Open apps and jump to Android App Info for user-confirmed uninstall.
- D-pad focusable controls.

## Platform limitations
- Cannot silently become the default launcher, uninstall apps, clear other apps' data, or remove protected system apps. Android controls those actions and may require confirmation.
- App enumeration and settings screens vary by Android release and TV vendor.
- Android 4.0 compatibility is a best-effort legacy target; test on the specific device.

## Build APK
Open this folder in Android Studio with JDK 17 and a current Android SDK installed. Sync Gradle, then choose Build > Build APK(s). Output is normally `app/build/outputs/apk/debug/app-debug.apk`.

**Build status:** source project only. This environment has no Gradle executable or Android SDK, so no installable APK has been compiled or verified here.

## Build without a computer (phone-only route)
This repository includes `.github/workflows/build-apk.yml`. Upload the project contents to a GitHub repository using your phone's browser, then open the repository's **Actions** tab and run **Build CleanMyTV APK** (or push to `main`). When the run finishes, open the run, scroll to **Artifacts**, and download `CleanMyTV-debug-apk`. Extract the ZIP to get `app-debug.apk`.

The APK is a debug build for testing, not a Play Store release. GitHub account and internet access are required. The build workflow has not been executed in this environment, so a successful APK is not yet verified.
